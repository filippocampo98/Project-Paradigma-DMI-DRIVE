import { update_content } from './update';

update_content("");